package com.example.iphonecam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var thumb: ImageView
    private lateinit var focusRing: View
    private var camera: Camera? = null
    private var capture: ImageCapture? = null
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var filterOn = true
    private val io = Executors.newSingleThreadExecutor()

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else finish()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        thumb = findViewById(R.id.thumb)
        focusRing = findViewById(R.id.focusRing)

        findViewById<View>(R.id.shutter).setOnClickListener { takePhoto() }
        findViewById<View>(R.id.flip).setOnClickListener {
            lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA)
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        findViewById<TextView>(R.id.flashBtn).setOnClickListener {
            flash = if (flash == ImageCapture.FLASH_MODE_OFF) ImageCapture.FLASH_MODE_ON
                    else ImageCapture.FLASH_MODE_OFF
            capture?.flashMode = flash
            (it as TextView).text = if (flash == ImageCapture.FLASH_MODE_ON) "⚡" else "⚡̸"
        }
        findViewById<TextView>(R.id.lookBtn).setOnClickListener {
            filterOn = !filterOn
            (it as TextView).text = if (filterOn) "iPhone: ON" else "iPhone: OFF"
        }
        mapOf(R.id.z05 to 0.5f, R.id.z1 to 1f, R.id.z2 to 2f).forEach { (id, r) ->
            findViewById<View>(id).setOnClickListener {
                val min = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(maxOf(r, min))
            }
        }
        preview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) { focusAt(e.x, e.y); v.performClick() }
            true
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else perm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flash).build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, lens, pv, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun focusAt(x: Float, y: Float) {
        val p = preview.meteringPointFactory.createPoint(x, y)
        camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(p).build())
        focusRing.x = x - focusRing.width / 2; focusRing.y = y - focusRing.height / 2
        focusRing.alpha = 1f; focusRing.scaleX = 1.4f; focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).start()
        }.start()
    }

    private fun takePhoto() {
        capture?.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                var bmp = image.toBitmap()
                val rot = image.imageInfo.rotationDegrees
                image.close()
                if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                    Matrix().apply { postRotate(rot.toFloat()) }, true)
                if (filterOn) bmp = applyIphoneLook(bmp)
                save(bmp)
                runOnUiThread { thumb.setImageBitmap(Bitmap.createScaledBitmap(bmp, 160, 160 * bmp.height / bmp.width, true)) }
            }
            override fun onError(e: ImageCaptureException) {}
        })
    }

    /** مظهر آيفون: دفء خفيف + تباين ناعم + ظلال مرفوعة + تشبّع معتدل */
    private fun applyIphoneLook(src: Bitmap): Bitmap {
        val c = 1.07f; val t = (1 - c) * 128f
        val cm = ColorMatrix().apply { setSaturation(1.06f) }
        cm.postConcat(ColorMatrix(floatArrayOf(
            c * 1.03f, 0f, 0f, 0f, t + 6,
            0f, c, 0f, 0f, t + 3,
            0f, 0f, c * 0.96f, 0f, t - 1,
            0f, 0f, 0f, 1f, 0f)))
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        })
        return out
    }

    private fun save(bmp: Bitmap) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/iPhoneCam")
        }
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let {
            contentResolver.openOutputStream(it)?.use { s -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, s) }
        }
    }
}
